import React from 'react';
import '../../App.css';

export default function Setting() {
  return <h1 className='Setting'>Setting</h1>;
}