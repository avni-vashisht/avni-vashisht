import React from 'react';
import '../../App.css';

export default function User() {
  return <h1 className='User'>User</h1>;
}