print('')
print('HOW WOULD YOU LIKE TO PLAY THE GAME ?   SINGLE PLAYER   OR   MULTIPLE PLAYERS')
print('')
print('ENTER  1  FOR SINGLE PLAYER AND  2  FOR MULTIPLE PLAYER')
print('')

print('   coordinates on board (x,y)')
print('   1,1 | 1,2 | 1,3')
print('   2,1 | 2,2 | 2,3')
print('   3,1 | 3,2 | 3,3')
print('')

b=['_','_','_','_','_','_',' ',' ',' ']

def board():
    print ('                                       ' )
    print ('          '+b[0]+'|'+b[1]+'|'+b[2])
    print ('          '+b[3]+'|'+b[4]+'|'+b[5])
    print ('          '+b[6]+'|'+b[7]+'|'+b[8])
    return ('                                        ')

#user input can be in any format this is to make our concerns only with the numerical values entered 
def coor(m):
    x=0
    c=[]
    while x<len(m):
        if 48<ord(m[x])<57:
            c.append(m[x])
        x=x+1
    if len(c)==2:
        n=str(c[0])+','+str(c[1])
    else:
        n='0,0'
    return n

#mapping of coordinates to indexes in list b
def coordinates(n,x):
    if n=='1,1':
        x=0
    if n=='1,2':
        x=1
    if n=='1,3':
        x=2
    if n=='2,1':
        x=3
    if n=='2,2':
        x=4
    if n=='2,3':
        x=5
    if n=='3,1':
        x=6
    if n=='3,2':
        x=7
    if n=='3,3':
        x=8
    if n=='0,0':
        x=9
    return x

#to make certain that the entered input is acceptable enough to continue the game, else ask to reenter the value
flag_go_ahead=0

while flag_go_ahead==0:
    print('')
    choice_to_play=input('  ENTER  1  OR  2  :  ')
    print('')
    
    if choice_to_play=='1' or choice_to_play=='2':
        flag_go_ahead=1
        if choice_to_play=='1':
            print('')
            print('CHOOSE A LEVEL TO PLAY: EASY , MEDIUM , DIFFICULT')
            print('')
            print('ENTER 1 FOR EASY , 2 FOR MEDIUM , 3 FOR DIFFICULT')
            print('')

            #again to check the validity of entered input 
            flag_start=0
            
            while flag_start==0:
                print('')
                level_to_play=input('ENTER  1  OR  2  OR  3 :  ')
                print('')
                
                if level_to_play=='1' or level_to_play=='2' or level_to_play=='3':
                    flag_start=1
                    
                    if level_to_play=='1':
                        
                        print(board())
                        x=''
                        y=''

                        #list is in the priority order of positions based on the probability of winning
                        d=[4,2,6,8,0,1,7,3,5]

                        end_of_game=0

                        while end_of_game==0:
                          flag_move_ahead=0
                          m=input('    user enter coordinates   ')
                          n=coor(m)
                          y=coordinates(n,x)
                          
                          a=0     
                          if y in d:
                        #for valid coordinates 
                            flag_move_ahead=1
                            while a<9 and end_of_game==0:
                              if a==y:
                                b[a]='X'
                                d.remove(y)
                              a=a+1

                          if flag_move_ahead==1:  
                            print(board())
                            
                        #winning situations of user
                            if b[0]==b[4]==b[8]=='X'or b[2]==b[4]==b[6]=='X' or b[0]==b[1]==b[2]=='X' or b[0]==b[3]==b[6]=='X'or b[2]==b[5]==b[8]=='X' or b[1]==b[4]==b[7]=='X' or b[3]==b[4]==b[5]=='X'or b[7]==b[8]==b[6]=='X':
                              end_of_game=1
                              print('"     user wins!      "')  
                            
                            if len(d)>0 and end_of_game==0:
                                print("      computer's turn")
                                x=d[0]
                                b[x]='0'
                                d.remove(x)

                                print(board())
                              
                        #winning situations of computer
                            if b[0]==b[4]==b[8]=='0'or b[2]==b[4]==b[6]=='0' or b[0]==b[1]==b[2]=='0' or b[0]==b[3]==b[6]=='0'or b[2]==b[5]==b[8]=='0' or b[1]==b[4]==b[7]=='0' or b[3]==b[4]==b[5]=='0'or b[8]==b[7]==b[6]=='0':
                                end_of_game=1
                                print('"     computer wins!      "')
                                j=5
                          if len(d)==0 and sum==0:
                              print('    match is draw')
                              end_of_game=1
                               
                        #if invalid coordinates
                          if flag_move_ahead==0:
                            print(' ')
                            print('  THIS COORDINATE IS EITHER ALREADY TAKEN OR INVALID.ENTER VALID COORDINATES.')
                            print(' ')
              


        #here begins the level 2 of the game.Contains only counter option and random selection.            
                    if level_to_play=='2':
                           
                        print(board())
                        x=''
                        y=''

                        #list is in the priority order of positions based on the probability of winning
                        d=[4,2,6,8,0,1,7,3,5]

                        #the indexes which are winning positions
                        win_list=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]

                        #the list with indexes of user's moves
                        cross_list=[]

                        end_of_game=0

                        while end_of_game==0:
                          flag_move_ahead=0
                          m=input('    user enter coordinates   ')
                          n=coor(m)
                          y=coordinates(n,x)
                          
                          a=0     
                          if y in d:
        #for valid coordinates 
                            flag_move_ahead=1
                            while a<9 and end_of_game==0:
                              if a==y:
                                b[a]='X'
                                cross_list.append(y)
                                d.remove(y)
                              a=a+1

                          if flag_move_ahead==1:  
                              print(board())
                            
        #winning situations of user
                              if b[0]==b[4]==b[8]=='X'or b[2]==b[4]==b[6]=='X' or b[0]==b[1]==b[2]=='X' or b[0]==b[3]==b[6]=='X'or b[2]==b[5]==b[8]=='X' or b[1]==b[4]==b[7]=='X' or b[3]==b[4]==b[5]=='X'or b[7]==b[8]==b[6]=='X':
                                end_of_game=1
                                print('"     user wins!      "')  
                                
                              if len(d)>0 and end_of_game==0:
                                print("      computer's turn")
                                  
                                flag_counter=0
                                  
                            #if there is need to counter a move         
                              for x in range(0,len(win_list)):
                                a=win_list[x]
                                count=0
                                for y in a:
                                    if y in cross_list and flag_counter==0:
                                      count=count+1
                                    if count==2 and flag_counter==0:
                                      for y in a:
                                         if y not in cross_list and y in d:
                                           b[y]='0'
                                           d.remove(y)
                                           flag_counter=1
                                           print(board())

                                            
                            #no such situation (random selection)       
                              if flag_counter==0 and len(d)>0:
                                  x=d[0]
                                  b[x]='0'
                                  d.remove(x)
                                  print(board())
                                  
                            #winning situations of computer
                              if b[0]==b[4]==b[8]=='0'or b[2]==b[4]==b[6]=='0' or b[0]==b[1]==b[2]=='0' or b[0]==b[3]==b[6]=='0'or b[2]==b[5]==b[8]=='0' or b[1]==b[4]==b[7]=='0' or b[3]==b[4]==b[5]=='0'or b[8]==b[7]==b[6]=='0':
                                  end_of_game=1
                                  print('"     computer wins!      "')
                                    
                              if len(d)==0 and end_of_game==0:
                                  print('    match is draw')
                                  end_of_game=1
                                   
                        #if invalid coordinates
                        if flag_move_ahead==0:
                            print(' ')
                            print('  THIS COORDINATE IS EITHER ALREADY TAKEN OR INVALID.ENTER VALID COORDINATES.')
                            print(' ')

#level 3 contains moves in favour , counter and random
                    if level_to_play=='3':
                        
                        print(board())
                        x=''
                        y=''

                        #list is in the priority order of positions based on the probability of winning
                        d=[4,2,6,8,0,1,7,3,5]

                        #the indexes which are winning positions
                        win_list=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]

                        #the list with indexes of user's moves
                        cross_list=[]

                        #the list with indexes of the computer's moves
                        zero_list=[]

                        end_of_game=0

                        while end_of_game==0:
                          flag_move_ahead=0
                          m=input('    user enter coordinates   ')
                          n=coor(m)
                          y=coordinates(n,x)
                          
                          a=0     
                          if y in d:
                        #for valid coordinates 
                            flag_move_ahead=1
                            while a<9 and end_of_game==0:
                              if a==y:
                                b[a]='X'
                                cross_list.append(y)
                                d.remove(y)
                              a=a+1

                          if flag_move_ahead==1:  
                                print(board())
                            
                            #winning situations of user
                                if b[0]==b[4]==b[8]=='X'or b[2]==b[4]==b[6]=='X' or b[0]==b[1]==b[2]=='X' or b[0]==b[3]==b[6]=='X'or b[2]==b[5]==b[8]=='X' or b[1]==b[4]==b[7]=='X' or b[3]==b[4]==b[5]=='X'or b[7]==b[8]==b[6]=='X':
                                  end_of_game=1
                                  print('"     user wins!      "')  
                                
                                if len(d)>0 and end_of_game==0:
                                  print("      computer's turn")
                                  
                                  flag_counter=0
                                  
                            #if there is any move in favor of the computer
                                  for x in range(0,len(win_list)):
                                    a=win_list[x]
                                    count=0
                                    for y in a:
                                      if y in zero_list and flag_counter==0:
                                        count=count+1
                                      if count==2 and flag_counter==0:
                                        for y in a:
                                          if y not in zero_list and y in d:
                                            b[y]='0'
                                            zero_list.append(y)
                                            d.remove(y)
                                            flag_counter=1
                                            print(board())

                            #if there is any need to counter a move          
                                  for x in range(0,len(win_list)):
                                    a=win_list[x]
                                    count=0
                                    for y in a:
                                      if y in cross_list and flag_counter==0:
                                        count=count+1
                                      if count==2 and flag_counter==0:
                                        for y in a:
                                          if y not in cross_list and y in d:
                                            b[y]='0'
                                            zero_list.append(y)
                                            d.remove(y)
                                            flag_counter=1
                                            print(board())
                                            
                            #no such situation(random selection)        
                                  if flag_counter==0:
                                    x=d[0]
                                    b[x]='0'
                                    zero_list.append(x)
                                    d.remove(x)
                                    print(board())

                                  
                                  
                            #winning situations of computer
                                  if b[0]==b[4]==b[8]=='0'or b[2]==b[4]==b[6]=='0' or b[0]==b[1]==b[2]=='0' or b[0]==b[3]==b[6]=='0'or b[2]==b[5]==b[8]=='0' or b[1]==b[4]==b[7]=='0' or b[3]==b[4]==b[5]=='0'or b[8]==b[7]==b[6]=='0':
                                    end_of_game=1
                                    print('"     computer wins!      "')
                                    j=5
                                  if len(d)==0 and end_of_game==0:
                                      print('    match is draw')
                                      end_of_game=1
                                   
                        #if invalid coordinates
                          if flag_move_ahead==0:
                            print(' ')
                            print('  THIS COORDINATE IS EITHER ALREADY TAKEN OR INVALID.ENTER VALID COORDINATES.')
                            print(' ')
                            
        #if there is any error in entering the input               
                else:
                    flag_start=0
                    print('PLEASE ENTER EITHER 1 OR 2 OR 3 (no commas or anything to be added)')

                    
        if choice_to_play=='2':
                   
                print(board())

                x=''
                y=''             

                end_of_game=0
                d=[0,1,2,3,4,5,6,7,8]

                #because there can be overwrite or an invalid value we need to make sure that the new value entered is acceptable and not used till now
                f=0

                while end_of_game==0:
                  #user1 turn
                  if end_of_game==0 and f==0:
                      m=input('    user 1 enter coordinates   ')
                      n=coor(m)
                      y=coordinates(n,x)
                      if y in d:
                        f=1
                        a=0
                        while a<9:
                          if a==y:
                            b[a]='X'
                            d.remove(y)
                          a=a+1
                    
                        print( board())
                    
                      else:
                        f=0
                        print('')
                        print( '     PLEASE ENTER A VALID COORDINATE. TRY AGAIN')
                        print('')

                   #after every move we need to check the winning condition     
                  if b[0]==b[4]==b[8]=='X'or b[2]==b[4]==b[6]=='X' or b[0]==b[1]==b[2]=='X' or b[0]==b[3]==b[6]=='X'or b[2]==b[5]==b[8]=='X' or b[1]==b[4]==b[7]=='X' or b[3]==b[4]==b[5]=='X'or b[7]==b[8]==b[6]=='X':
                    
                    end_of_game=1
                    print('"user 1 wins!"')
                    
                  if end_of_game==0 and f==1:
                      m=input('    user 2 enter coordinates   ')
                      n=coor(m)
                      y=coordinates(n,x)
                      if y in d:
                        f=0
                      if y in d:  
                        a=0
                        while a<9:
                          if a==y:
                            b[a]='0'
                            d.remove(y)
                          a=a+1
                        print( board())
                      else:
                        f=1
                        print('')
                        print('     PLEASE ENTER A VALID COORDINATE. TRY AGAIN')
                        print('')
                 
                  if b[0]==b[4]==b[8]=='0'or b[2]==b[4]==b[6]=='0' or b[0]==b[1]==b[2]=='0' or b[0]==b[3]==b[6]=='0'or b[2]==b[5]==b[8]=='0' or b[1]==b[4]==b[7]=='0' or b[3]==b[4]==b[5]=='0'or b[7]==b[8]==b[6]=='0':
                    
                    end_of_game=1
                    print('"user 2 wins!"')

                  #we need to check wheter the game has completed without a winner
                  if len(d)==0 and end_of_game==0:
                    end_of_game=1
                    print('  THE MATCH IS DRAW')


    else:
        flag_go_ahead=0
        print('PLEASE ENTER EITHER 0 OR 1 (no commas or anythimg to be added)')
